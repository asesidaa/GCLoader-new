#!/usr/bin/env python3
"""
End-to-End Game Decryption CLI.

Usage:
  python -m gamecrypt --base-dir D:/TTXZero --port COM4 --mbr-dump mbr.bin
  python -m gamecrypt --offline --asset-decrypted asset.decrypted
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .chain import (
    run_full_chain, OFFSET_A4, MBR_AUTH_OFFSET,
    BIOS_BUS_RESET_CMD, BIOS_SENSE_NODE80_CMD,
)

# Default base directory — the root of the original C: drive image
# containing ZEROBoot.exe and the zero/ subdirectory.
DEFAULT_BASE_DIR = Path("H:/gc/artifacts/zero_c")


def _hexarg(s: str) -> bytes:
    return bytes.fromhex(s.replace(" ", ""))


def main():
    p = argparse.ArgumentParser(
        description="End-to-End Game Decryption: Dongle → game.exe",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Live mode (--base-dir points to the root with ZEROBoot.exe + zero/):
  python -m gamecrypt --base-dir D:/TTXZero --port COM4 --mbr-dump mbr.bin

  # Live mode with explicit paths:
  python -m gamecrypt --zb-exe D:/TTXZero/ZEROBoot.exe --zero-dir D:/TTXZero/zero \\
      --port COM4 --mbr-dump mbr.bin

  # Offline mode (no dongle):
  python -m gamecrypt --offline --asset-decrypted asset.decrypted
        """,
    )
    p.add_argument("--port", default="COM4", help="Serial port (default: COM4)")

    # Base dir — derives zb-exe and zero-dir unless overridden
    p.add_argument("--base-dir", type=Path, default=DEFAULT_BASE_DIR,
                   help="Root directory containing ZEROBoot.exe and zero/ subdirectory")
    p.add_argument("--zb-exe", type=Path, default=None,
                   help="Path to ZEROBoot.exe (defaults to <base-dir>/ZEROBoot.exe)")
    p.add_argument("--zero-dir", type=Path, default=None,
                   help="Directory with zero/* encrypted assets (defaults to <base-dir>/zero)")
    p.add_argument("--game-dir", type=Path, default=Path("H:/gc"),
                   help="Directory with game.exe and game.dat")
    p.add_argument("--output-dir", type=Path, default=Path("H:/gc/tmp"),
                   help="Output directory")

    # Offline mode
    p.add_argument("--offline", action="store_true",
                   help="Skip dongle, use cached keys")
    p.add_argument("--launcher-key", type=_hexarg, help="16-byte launcher key (hex)")
    p.add_argument("--appkey", type=_hexarg, help="32-byte AppKey (hex)")
    p.add_argument("--asset-decrypted", type=Path,
                   help="Pre-decrypted game asset path")

    # Preamble
    p.add_argument("--mbr-auth", type=_hexarg, help="21-byte MBR auth request (hex)")
    p.add_argument("--mbr-dump", type=Path,
                   help=f"512-byte MBR dump (auth bytes read from offset 0x{MBR_AUTH_OFFSET:X})")
    p.add_argument("--bus-reset-cmd", type=_hexarg, help="JVS bus reset command (hex)")
    p.add_argument("--sense-node80-cmd", type=_hexarg, help="Sense node 0x80 command (hex)")
    p.add_argument("--skip-preamble", action="store_true",
                   help="Skip BIOS/MBR preamble")

    # Advanced
    p.add_argument("--offset-a4", type=lambda x: int(x, 0), default=OFFSET_A4,
                   help=f"Offset of a4 in decrypted asset (default: 0x{OFFSET_A4:X})")

    args = p.parse_args()

    # Resolve base-dir → zb-exe + zero-dir (only if not explicitly overridden)
    base_dir = args.base_dir
    zb_exe = args.zb_exe or (base_dir / "ZEROBoot.exe")
    zero_dir = args.zero_dir or (base_dir / "zero")

    # Resolve MBR auth
    mbr_auth = None
    if args.mbr_auth:
        mbr_auth = args.mbr_auth
    elif args.mbr_dump:
        dump = args.mbr_dump.read_bytes()
        if len(dump) >= MBR_AUTH_OFFSET + 21:
            mbr_auth = dump[MBR_AUTH_OFFSET:MBR_AUTH_OFFSET + 21]
            print(f"Extracted MBR auth: {mbr_auth.hex()}")
        else:
            print(f"ERROR: MBR dump too small ({len(dump)} bytes)", file=sys.stderr)
            return 1
    elif not args.offline and not args.skip_preamble:
        print("ERROR: Live mode requires --mbr-dump or --mbr-auth.", file=sys.stderr)
        print("Extract from the original HDD boot sector:", file=sys.stderr)
        print("  sudo dd if=/dev/sdX of=mbr.bin bs=512 count=1", file=sys.stderr)
        print(f"  python -m gamecrypt --mbr-dump mbr.bin --port {args.port}", file=sys.stderr)
        print("Or skip preamble with --skip-preamble (dongle must already be initialized).", file=sys.stderr)
        return 1

    # Load pre-decrypted asset
    decrypted_asset = None
    if args.asset_decrypted:
        decrypted_asset = args.asset_decrypted.read_bytes()
        print(f"Loaded pre-decrypted asset: {args.asset_decrypted} "
              f"({len(decrypted_asset)} bytes)")

    try:
        run_full_chain(
            port=args.port,
            zb_exe=zb_exe,
            zero_dir=zero_dir,
            game_dir=args.game_dir,
            output_dir=args.output_dir,
            mbr_auth=mbr_auth,
            bus_reset_cmd=args.bus_reset_cmd,
            sense_node80_cmd=args.sense_node80_cmd,
            skip_preamble=args.skip_preamble,
            offline=args.offline,
            launcher_key=args.launcher_key,
            appkey=args.appkey,
            decrypted_asset=decrypted_asset,
            offset_a4=args.offset_a4,
        )
    except Exception as e:
        print(f"\nFATAL: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
