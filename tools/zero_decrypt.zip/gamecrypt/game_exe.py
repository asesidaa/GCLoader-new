"""
game.exe .text section decryption.

Extracts the XOR key from the code buffer entry code (via capstone),
decrypts the 56-byte Blowfish key from params[40:54], runs the key
schedule, and ECB-decrypts the .text section.
"""
from __future__ import annotations
import struct


def extract_xor_key(code_buffer: bytes) -> bytes:
    """Extract 56-byte XOR key from code buffer entry code (0x00-0xF4).

    Uses capstone for accurate x86 disassembly. The entry code does:
      - XOR [ECX+offset], imm8  for most bytes
      - MOV reg, imm8; XOR [ECX+offset], reg  for others
      - NOT BL; MOV [ECX+6], BL  for byte 6 (special case)
    """
    from capstone import Cs, CS_ARCH_X86, CS_MODE_32

    md = Cs(CS_ARCH_X86, CS_MODE_32)
    md.detail = True

    xor_key = bytearray(56)
    regs = {r: 0 for r in ["al", "bl", "dl", "cl", "ah", "bh", "ch", "dh"]}

    for insn in md.disasm(code_buffer[:0x100], 0x0):
        if insn.address >= 0xF7:
            break
        n_ops = len(insn.operands)

        if insn.mnemonic == "xor" and n_ops == 2:
            dst, src = insn.operands[0], insn.operands[1]
            if dst.type == 3:  # memory
                if insn.reg_name(dst.mem.base) == "ecx":
                    disp = dst.mem.disp
                    if src.type == 2:  # immediate
                        if 0 <= disp < 56:
                            xor_key[disp] ^= (src.imm & 0xFF)
                    elif src.type == 1:  # register
                        rn = insn.reg_name(src.reg)
                        if rn in regs and 0 <= disp < 56:
                            xor_key[disp] ^= regs[rn]

        if insn.mnemonic == "mov" and n_ops == 2:
            dst, src = insn.operands[0], insn.operands[1]
            if dst.type == 1 and src.type == 2:
                rn = insn.reg_name(dst.reg)
                if rn in regs:
                    regs[rn] = src.imm & 0xFF

        if insn.mnemonic == "not" and n_ops == 1:
            dst = insn.operands[0]
            if dst.type == 1:
                rn = insn.reg_name(dst.reg)
                if rn in regs:
                    regs[rn] = (~regs[rn]) & 0xFF

    return bytes(xor_key)


def decrypt_game_exe(game_exe_path: str, params: list,
                     code_buffer: bytes, xor_key: bytes) -> bytes:
    """Decrypt game.exe's .text section. Returns the full decrypted EXE bytes."""
    from .blowfish import derive_keys, decrypt_ecb, PI_P_ARRAY, PI_S_BOXES

    with open(game_exe_path, "rb") as f:
        game_exe = bytearray(f.read())

    # ── Derive Blowfish key ──
    encrypted_key = b"".join(struct.pack("<I", params[i]) for i in range(40, 54))
    decrypted_key = bytearray(56)
    for i in range(56):
        decrypted_key[i] = encrypted_key[i] ^ xor_key[i]
    decrypted_key[6] = (~encrypted_key[6]) & 0xFF  # NOT, not XOR

    # ── Key schedule ──
    key_str = bytes(decrypted_key).decode("latin-1")
    P, T0, T1, T2, T3 = derive_keys(
        key_str, PI_P_ARRAY,
        PI_S_BOXES[0], PI_S_BOXES[1],
        PI_S_BOXES[2], PI_S_BOXES[3],
    )

    # ── Find .text section ──
    pe_off = struct.unpack_from("<I", game_exe, 0x3C)[0]
    num_sec = struct.unpack_from("<H", game_exe, pe_off + 6)[0]
    opt_hdr = struct.unpack_from("<H", game_exe, pe_off + 20)[0]
    sec_off = pe_off + 24 + opt_hdr

    text_raw = 0
    text_size = 0
    for i in range(num_sec):
        off = sec_off + i * 40
        name = game_exe[off:off+8].rstrip(b"\x00").decode("ascii", errors="replace")
        if name == ".text":
            text_size = struct.unpack_from("<I", game_exe, off + 16)[0]
            text_raw = struct.unpack_from("<I", game_exe, off + 20)[0]
            break

    if not text_raw:
        raise RuntimeError("Could not find .text section in game.exe")

    # ── Decrypt ──
    text_data = game_exe[text_raw:text_raw + text_size]
    decrypted_text = decrypt_ecb(text_data, P, T0, T1, T2, T3)

    output = bytearray(game_exe)
    output[text_raw:text_raw + text_size] = decrypted_text
    return bytes(output)
