"""
Full decryption chain orchestrator.

All GUIDs, key material, and secdata content are extracted dynamically
from binaries. No hardcoded system-specific values.

Phases:
  Pre. BIOS/MBR preamble (live only) — bus reset, sense node, MBR auth
  0. ZEROBoot 4-phase dongle handshake → launcher_key
  1. Decrypt intermediate EXE
  2. Intermediate EXE 4-phase dongle handshake → AppKey
  3. Decrypt game asset
  4. Extract a4 + v42
  5. Decrypt game.dat → params, DLL, code buffer
  6. Extract XOR key from code buffer
  7. Decrypt game.exe .text
"""
from __future__ import annotations

import hashlib
import struct
import time
from pathlib import Path
from typing import Optional, Callable

from . import rc4
from .link import SerialLink, JvsLink
from .encoding import (
    encode_variant_a, decode_variant_a,
    encode_variant_b, decode_variant_b,
    encode_variant_c, decode_variant_c,
)
from .game_dat import decrypt_game_dat
from .game_exe import extract_xor_key, decrypt_game_exe
from .extract import (
    extract_zeroboot,
    extract_intermediate,
    decrypt_secdata,
    load_secdata_host,
    load_secdata_dongle,
)


# ── Constants (NOT system-specific) ──────────────────────────────────────────

OFFSET_A4 = 0x1060
MBR_AUTH_OFFSET = 0x190

# Default MBR preamble commands (these are JVS protocol constants, not secrets)
BIOS_BUS_RESET_CMD  = bytes.fromhex("E0 00 02 FF 01")
BIOS_SENSE_NODE80_CMD = bytes.fromhex("E0 80 02 FE 80")

# Path defaults — can be overridden via CLI
DEFAULT_ZB_EXE = Path("H:/gc/artifacts/zero_c/ZEROBoot.exe")


# ═══════════════════════════════════════════════════════════════════════════════
# BIOS/MBR preamble (live only)
# ═══════════════════════════════════════════════════════════════════════════════

def preamble_bios_mbr(
    link: JvsLink,
    mbr_auth: bytes,
    bus_reset_cmd: bytes = BIOS_BUS_RESET_CMD,
    sense_node80_cmd: bytes = BIOS_SENSE_NODE80_CMD,
    log: Callable = print,
) -> bytes:
    """BIOS/MBR preamble: bus reset → sense node 0x80 → MBR auth."""
    log("=== Preamble: BIOS/MBR Init ===")

    # Step 1: Bus reset
    log(f"  [BIOS] Bus reset: {bus_reset_cmd.hex(' ')}")
    frames = link.send_raw(bus_reset_cmd, timeout_s=2.0)
    if frames:
        p = frames[0].payload
        log(f"  Bus reset ACK (status=0x{p[0]:02X} report=0x{p[1]:02X})")
    else:
        log("  WARNING: no bus reset ACK, continuing anyway")
    log("  Waiting 500ms for dongle init...")
    time.sleep(0.5)
    link.transport.drain(0.1)

    # Step 2: Sense node 0x80 → ATA password
    log(f"  [BIOS] Sense node 0x80: {sense_node80_cmd.hex(' ')}")
    for attempt in range(3):
        frames = link.send_raw(sense_node80_cmd, timeout_s=2.0)
        if frames and frames[0].payload[0] == 1 and frames[0].payload[1] == 1:
            break
        if attempt < 2:
            log(f"  Retry {attempt + 1}/2: no valid response, waiting 300ms...")
            time.sleep(0.3)
            link.transport.drain(0.1)
    else:
        raise RuntimeError("BIOS sense node 0x80: no response after 3 attempts")
    p = frames[0].payload
    ata_password = bytes(p[2:])
    log(f"  ATA password received ({len(ata_password)} bytes)")
    link.transport.drain(0.1)

    # Step 3: MBR node-0x80 auth request
    log(f"  [MBR] Auth request: {mbr_auth.hex(' ')}")
    for attempt in range(3):
        frames = link.send_raw(mbr_auth, timeout_s=2.0)
        if frames:
            break
        if attempt < 2:
            log(f"  Retry {attempt + 1}/2: no response, waiting 300ms...")
            time.sleep(0.3)
            link.transport.drain(0.1)
    else:
        raise RuntimeError("MBR auth request: no response after 3 attempts (wrong MBR bytes?)")
    log(f"  MBR auth OK (status=0x{frames[0].payload[0]:02X})")
    link.transport.drain(0.1)

    log("  Preamble complete")
    return ata_password


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 0: ZEROBoot handshake
# ═══════════════════════════════════════════════════════════════════════════════

def phase0_zeroboot(link: JvsLink, secdata_host_plain: bytes,
                    log: Callable = print) -> bytes:
    """ZEROBoot 4-phase handshake → launcher_key (16 bytes)."""
    log("=== Phase 0: ZEROBoot Handshake ===")
    z = bytes(16)
    s = secdata_host_plain

    # P1: Start HOST Secure Comm
    p1 = link.exchange(0x00, b"\x80" + encode_variant_b(s[:16], z), "zb.p1")
    if p1[0] != 1 or p1[1] != 1:
        raise RuntimeError(f"ZB-P1 FAILED: 0x{p1[0]:02X}/0x{p1[1]:02X}")
    hc = decode_variant_b(bytes(p1[2:34]), z)
    log(f"  host_challenge={hc.hex()}")

    # P2: Get DONGLE Secure Pass
    p2 = link.exchange(0x00, b"\x81" + s[16:48], "zb.p2")
    if p2[0] != 1 or p2[1] != 1:
        raise RuntimeError(f"ZB-P2 FAILED: 0x{p2[0]:02X}/0x{p2[1]:02X}")
    dp = decode_variant_b(bytes(p2[2:34]), hc)
    log(f"  dongle_pass={dp.hex()}")

    # P3: Start DONGLE Secure Comm
    p3 = link.exchange(0x80, b"\x80" + encode_variant_a(dp, z), "zb.p3")
    if p3[0] != 1 or p3[1] != 1:
        raise RuntimeError(f"ZB-P3 FAILED: 0x{p3[0]:02X}/0x{p3[1]:02X}")
    dc = decode_variant_a(bytes(p3[2:34]), z)
    log(f"  dongle_challenge={dc.hex()}")

    # P4: Get Launcher Key
    p4 = link.exchange(0x80, b"\x85" + encode_variant_a(s[48:64], dc), "zb.p4")
    if p4[0] != 1 or p4[1] != 1:
        raise RuntimeError(f"ZB-P4 FAILED: 0x{p4[0]:02X}/0x{p4[1]:02X}")
    lk = decode_variant_a(bytes(p4[2:34]), dc)
    log(f"  launcher_key={lk.hex()}")

    return lk


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 1: Decrypt intermediate EXE
# ═══════════════════════════════════════════════════════════════════════════════

def phase1_decrypt_intermediate(zero_dir: Path, intermediate_guid: bytes,
                                launcher_key: bytes,
                                log: Callable = print) -> bytes:
    """Decrypt intermediate EXE with RC4(MD5(launcher_key))."""
    from .extract import _guid_bytes_to_string
    log("=== Phase 1: Decrypt Intermediate EXE ===")
    guid_str = _guid_bytes_to_string(intermediate_guid)
    path = zero_dir / guid_str
    encrypted = path.read_bytes()
    log(f"  {path.name} ({len(encrypted)} bytes)")
    decrypted = rc4.rc4_decrypt(launcher_key, encrypted)
    if decrypted[:2] != b"MZ":
        raise RuntimeError("Intermediate EXE decryption FAILED (bad key)")
    log(f"  Valid PE ({len(decrypted)} bytes)")
    return decrypted


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 2: Intermediate handshake
# ═══════════════════════════════════════════════════════════════════════════════

def phase2_intermediate(link: JvsLink, dongle_pass: bytes,
                        dongle_challenge: bytes,
                        candidate_lk: bytes, candidate_extra: bytes,
                        log: Callable = print) -> bytes:
    """Intermediate EXE 4-phase handshake → AppKey (32 bytes)."""
    log("=== Phase 2: Intermediate Handshake ===")
    z = bytes(16)

    # P1: Start DONGLE Secure Comm (1)
    p1 = link.exchange(0x80, b"\x80" + encode_variant_a(dongle_pass, z), "im.p1")
    if p1[0] != 1 or p1[1] != 1:
        raise RuntimeError(f"IM-P1 FAILED: 0x{p1[0]:02X}/0x{p1[1]:02X}")
    dc1 = decode_variant_a(bytes(p1[2:34]), z)
    log(f"  dc1={dc1.hex()}")

    # P2: Auth → AppKey[0:16]
    p2 = link.exchange(0x80, b"\x86" + encode_variant_c(dongle_challenge, dc1), "im.p2")
    if p2[0] != 1 or p2[1] != 1:
        raise RuntimeError(f"IM-P2 FAILED: 0x{p2[0]:02X}/0x{p2[1]:02X}")
    ak1 = decode_variant_c(bytes(p2[2:34]), dc1)
    log(f"  AppKey[0:16]={ak1.hex()}")

    # P3: Start DONGLE Secure Comm (2)
    p3 = link.exchange(0x80, b"\x80" + encode_variant_a(dongle_pass, z), "im.p3")
    if p3[0] != 1 or p3[1] != 1:
        raise RuntimeError(f"IM-P3 FAILED: 0x{p3[0]:02X}/0x{p3[1]:02X}")
    dc2 = decode_variant_a(bytes(p3[2:34]), z)
    log(f"  dc2={dc2.hex()}")

    # P4: Get DONGLE Packet Key → AppKey[16:32]
    p4 = link.exchange(0x80, b"\x81" + candidate_lk + candidate_extra, "im.p4")
    if p4[0] != 1 or p4[1] != 1:
        raise RuntimeError(f"IM-P4 FAILED: 0x{p4[0]:02X}/0x{p4[1]:02X}")
    ak2 = decode_variant_c(bytes(p4[2:34]), dc2)
    log(f"  AppKey[16:32]={ak2.hex()}")

    appkey = ak1 + ak2
    log(f"  AppKey={appkey.hex()}")
    return appkey


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 3: Decrypt game asset
# ═══════════════════════════════════════════════════════════════════════════════

def phase3_decrypt_asset(zero_dir: Path, game_asset_guid: bytes,
                         appkey: bytes, log: Callable = print) -> bytes:
    """Decrypt game asset with RC4(MD5(AppKey[:16]))."""
    from .extract import _guid_bytes_to_string
    log("=== Phase 3: Decrypt Game Asset ===")
    guid_str = _guid_bytes_to_string(game_asset_guid)
    path = zero_dir / guid_str
    encrypted = path.read_bytes()
    log(f"  {path.name} ({len(encrypted)} bytes)")
    decrypted = rc4.rc4_decrypt(appkey[:16], encrypted)
    expected_md5 = decrypted[:16]
    actual_data = decrypted[16:]
    if hashlib.md5(actual_data).digest() != expected_md5:
        raise RuntimeError("Game asset MD5 mismatch")
    log(f"  MD5 OK, data={len(actual_data)} bytes")
    return decrypted


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 4-7: Static decryption (no dongle needed)
# ═══════════════════════════════════════════════════════════════════════════════

def phases_static(
    decrypted_asset: bytes,
    game_dir: Path,
    offset_a4: int = OFFSET_A4,
    log: Callable = print,
) -> bytes:
    """Run phases 4-7: game.dat → code buffer → game.exe."""
    # Phase 4: Extract keys
    log("=== Phase 4: Extract Keys ===")
    a4 = struct.unpack_from("<I", decrypted_asset, offset_a4)[0]
    log(f"  a4 = 0x{a4:08X} (offset 0x{offset_a4:X})")
    game_dat_path = game_dir / "game.dat"
    game_dat_raw = game_dat_path.read_bytes()
    v42 = struct.unpack_from("<I", game_dat_raw, 0)[0]
    log(f"  v42 = 0x{v42:08X}")

    # Phase 5: Decrypt game.dat
    log("=== Phase 5: Decrypt game.dat ===")
    gd = decrypt_game_dat(game_dat_raw, a4, v42)
    if gd is None:
        raise RuntimeError("game.dat decryption FAILED")
    log(f"  DLL={gd['dll_size']}B  Code={gd['code_size']}B  "
        f"ImageBase=0x{gd['params'][1]:08X}  TextSize=0x{gd['params'][15]:X}")

    # Phase 6: Extract XOR key
    log("=== Phase 6: Extract XOR Key ===")
    xor_key = extract_xor_key(gd["code_data"])
    nz = sum(1 for b in xor_key if b != 0)
    log(f"  XOR key: {nz} non-zero bytes")

    # Phase 7: Decrypt game.exe
    log("=== Phase 7: Decrypt game.exe ===")
    game_exe_path = str(game_dir / "game.exe")
    result = decrypt_game_exe(game_exe_path, gd["params"],
                              gd["code_data"], xor_key)
    log(f"  Decrypted {len(result)} bytes")
    return result


# ═══════════════════════════════════════════════════════════════════════════════
# Main orchestrator
# ═══════════════════════════════════════════════════════════════════════════════

def run_full_chain(
    *,
    port: str = "COM4",
    game_dir: Path,
    zero_dir: Path,
    output_dir: Path,
    zb_exe: Optional[Path] = None,
    mbr_auth: Optional[bytes] = None,
    bus_reset_cmd: Optional[bytes] = None,
    sense_node80_cmd: Optional[bytes] = None,
    skip_preamble: bool = False,
    offline: bool = False,
    launcher_key: Optional[bytes] = None,
    appkey: Optional[bytes] = None,
    decrypted_asset: Optional[bytes] = None,
    offset_a4: int = OFFSET_A4,
    log: Callable = print,
) -> bytes:
    """Execute the complete decryption chain.

    All GUIDs and key material are extracted dynamically from ZEROBoot.exe
    and the decrypted intermediate EXE. Nothing is hardcoded.
    """
    started = time.monotonic()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # ── Step 0: Extract config from ZEROBoot.exe ──
    zb_exe = Path(zb_exe) if zb_exe else DEFAULT_ZB_EXE
    log(f"Extracting from ZEROBoot.exe: {zb_exe}")
    zb_cfg = extract_zeroboot(zb_exe)
    log(f"  Intermediate EXE GUID: {zb_cfg['intermediate_guid_str']}")
    log(f"  Host secdata GUID:     {zb_cfg['host_secdata_guid_str']}")
    log(f"  Key material:          {zb_cfg['key_material'].hex()}")

    # ── Step 1: Decrypt host secdata ──
    log(f"\nDecrypting host secdata...")
    secdata_host_plain = load_secdata_host(
        zero_dir, zb_cfg["host_secdata_guid"], zb_cfg["key_material"])
    log(f"  Secdata host plain: {len(secdata_host_plain)} bytes")

    # Validate size
    if len(secdata_host_plain) != 64:
        raise RuntimeError(
            f"Host secdata decrypted to {len(secdata_host_plain)} bytes, expected 64. "
            f"Key material or GUID may be wrong for this dongle pair.")

    link = None
    try:
        if not offline:
            log("\n" + "=" * 70)
            log("LIVE MODE: Dongle handshakes")
            log("=" * 70)

            transport = SerialLink(port)
            transport.open()
            link = JvsLink(transport)

            # Preamble
            if not skip_preamble:
                if mbr_auth is None:
                    raise ValueError(
                        "Live mode requires MBR auth bytes. "
                        "Extract from the original HDD boot sector:\n"
                        "  sudo dd if=/dev/sdX of=mbr.bin bs=512 count=1\n"
                        "  python -m gamecrypt --mbr-dump mbr.bin --port {port}\n"
                        "Or skip with --skip-preamble (only works if already booted)."
                    )
                preamble_bios_mbr(
                    link, mbr,
                    bus_reset_cmd=bus_reset_cmd or BIOS_BUS_RESET_CMD,
                    sense_node80_cmd=sense_node80_cmd or BIOS_SENSE_NODE80_CMD,
                    log=log,
                )

            # Phase 0
            if launcher_key is None:
                launcher_key = phase0_zeroboot(
                    link, secdata_host_plain, log=log)
                log(f"\n  LAUNCHER_KEY={launcher_key.hex()}")

            # Phase 1: Decrypt intermediate EXE
            intermediate = phase1_decrypt_intermediate(
                zero_dir, zb_cfg["intermediate_guid"], launcher_key, log=log)
            (output_dir / "intermediate_decrypted.exe").write_bytes(intermediate)

        else:
            log("\n" + "=" * 70)
            log("OFFLINE MODE: Using cached keys")
            log("=" * 70)
            if launcher_key:
                log(f"  LAUNCHER_KEY={launcher_key.hex()}")

            # Need intermediate EXE decrypted for extraction even in offline mode
            if launcher_key:
                intermediate = phase1_decrypt_intermediate(
                    zero_dir, zb_cfg["intermediate_guid"], launcher_key, log=log)
                (output_dir / "intermediate_decrypted.exe").write_bytes(intermediate)
            else:
                # Try to load previously decrypted intermediate
                cached = output_dir / "intermediate_decrypted.exe"
                if cached.exists():
                    intermediate = cached.read_bytes()
                    log(f"  Loaded cached intermediate: {len(intermediate)} bytes")
                else:
                    raise RuntimeError(
                        "Offline mode requires --launcher-key to decrypt "
                        "the intermediate EXE for config extraction")

        # ── Step 2: Extract config from decrypted intermediate EXE ──
        log(f"\nExtracting from intermediate EXE...")
        im_cfg = extract_intermediate(intermediate)
        log(f"  Dongle config GUID: {im_cfg['dongle_config_guid_str']}")
        log(f"  Game asset GUID:    {im_cfg['game_asset_guid_str']}")

        # ── Step 3: Decrypt dongle config ──
        log(f"\nDecrypting dongle config...")
        dongle_plain = load_secdata_dongle(
            zero_dir, im_cfg["dongle_config_guid"], im_cfg["key_material"])
        log(f"  Dongle config: {len(dongle_plain)} bytes")

        if len(dongle_plain) != 64:
            raise RuntimeError(
                f"Dongle config decrypted to {len(dongle_plain)} bytes, expected 64.")

        # Split dongle config into 4×16-byte slots
        dongle_pass      = dongle_plain[0:16]
        dongle_challenge = dongle_plain[16:32]
        candidate_lk     = dongle_plain[32:48]
        candidate_extra  = dongle_plain[48:64]
        log(f"  DONGLE_PASS:      {dongle_pass.hex()}")
        log(f"  DONGLE_CHALLENGE: {dongle_challenge.hex()}")
        log(f"  CANDIDATE_LK:     {candidate_lk.hex()}")
        log(f"  CANDIDATE_EXTRA:  {candidate_extra.hex()}")

        if link is not None:
            # Phase 2
            if appkey is None:
                appkey = phase2_intermediate(
                    link, dongle_pass, dongle_challenge,
                    candidate_lk, candidate_extra, log=log)
                log(f"\n  APPKEY={appkey.hex()}")

            # Phase 3
            if decrypted_asset is None:
                decrypted_asset = phase3_decrypt_asset(
                    zero_dir, im_cfg["game_asset_guid"], appkey, log=log)
                (output_dir / f"{im_cfg['game_asset_guid_str']}.decrypted").write_bytes(
                    decrypted_asset)

        if appkey:
            log(f"  APPKEY={appkey.hex()}")

        if decrypted_asset is None:
            raise ValueError("decrypted_asset required for phases 4-7")

        # Phases 4-7
        result = phases_static(decrypted_asset, game_dir, offset_a4, log=log)

        out_path = output_dir / "game_decrypted.exe"
        out_path.write_bytes(result)
        log(f"\n{'=' * 70}")
        log(f"COMPLETE: {time.monotonic() - started:.1f}s")
        log(f"Output: {out_path}")
        log(f"{'=' * 70}")

        return result

    finally:
        if link:
            link.transport.close()
