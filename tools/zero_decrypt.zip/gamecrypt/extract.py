"""
Dynamic extraction of GUIDs, key material, and secdata from binaries.

Instead of hardcoding system-specific values, this module reads them
from ZEROBoot.exe and the decrypted intermediate EXE at runtime.

Every harddrive/dongle pair has unique GUIDs and keys, but they are
stored at fixed RVAs within each binary's .data section.

PE parsing with RVA→file-offset conversion ensures we read the right
data regardless of section alignment.
"""
from __future__ import annotations

import hashlib
import struct
from pathlib import Path
from typing import Optional

from . import rc4


# ── Known RVAs (image base 0x400000) ──────────────────────────────────────────
# These offsets within the .data section are stable across builds.

# ZEROBoot.exe
ZEROBOOT_RVA_INTERMEDIATE_GUID = 0x201A8   # 14-byte GUID for intermediate EXE
ZEROBOOT_RVA_KEY_MATERIAL      = 0x201C8   # 14-byte secdata decryption key
ZEROBOOT_RVA_HOST_SECDATA_GUID = 0x201D8   # 14-byte GUID for host secdata

# Decrypted intermediate EXE (temp1.exe)
INTERMEDIATE_RVA_GAME_ASSET_GUID   = 0x4539C  # 14-byte GUID for game asset
INTERMEDIATE_RVA_KEY_MATERIAL      = 0x453CC  # 14-byte secdata decryption key
INTERMEDIATE_RVA_DONGLE_CONFIG_GUID = 0x45438  # 14-byte GUID for dongle config


class PEFile:
    """Lightweight PE parser for RVA ↔ file offset conversion."""

    def __init__(self, data: bytes):
        self.data = data
        self._parse()

    def _parse(self) -> None:
        data = self.data
        pe_off = struct.unpack_from("<I", data, 0x3C)[0]
        if data[pe_off : pe_off + 4] != b"PE\0\0":
            raise ValueError("Not a valid PE file")

        file_hdr_off = pe_off + 4
        num_sections = struct.unpack_from("<H", data, file_hdr_off + 2)[0]
        opt_hdr_off = file_hdr_off + 20
        magic = struct.unpack_from("<H", data, opt_hdr_off)[0]

        if magic == 0x10B:  # PE32
            self.image_base = struct.unpack_from("<I", data, opt_hdr_off + 28)[0]
            size_opt = struct.unpack_from("<H", data, file_hdr_off + 16)[0]
        elif magic == 0x20B:  # PE32+
            self.image_base = struct.unpack_from("<Q", data, opt_hdr_off + 24)[0]
            size_opt = struct.unpack_from("<H", data, file_hdr_off + 16)[0]
        else:
            raise ValueError(f"Unknown PE magic: 0x{magic:04X}")

        sec_off = opt_hdr_off + size_opt
        self.sections: list[tuple[str, int, int, int, int]] = []
        for i in range(num_sections):
            so = sec_off + i * 40
            name = data[so : so + 8].rstrip(b"\x00").decode("ascii", errors="replace")
            vsize = struct.unpack_from("<I", data, so + 8)[0]
            vaddr = struct.unpack_from("<I", data, so + 12)[0]
            rsize = struct.unpack_from("<I", data, so + 16)[0]
            roff = struct.unpack_from("<I", data, so + 20)[0]
            self.sections.append((name, vaddr, vsize, roff, rsize))

    def rva_to_offset(self, rva: int) -> Optional[int]:
        """Convert RVA to file offset. Returns None if RVA has no file data."""
        for _name, vaddr, vsize, roff, rsize in self.sections:
            if vaddr <= rva < vaddr + vsize:
                section_off = rva - vaddr
                if section_off < rsize:
                    return roff + section_off
                return None  # BSS / beyond raw data
        return None

    def va_to_offset(self, va: int) -> Optional[int]:
        """Convert virtual address to file offset."""
        return self.rva_to_offset(va - self.image_base)

    def read_rva(self, rva: int, size: int) -> Optional[bytes]:
        """Read bytes at the given RVA."""
        off = self.rva_to_offset(rva)
        if off is None or off + size > len(self.data):
            return None
        return self.data[off : off + size]

    def read_va(self, va: int, size: int) -> Optional[bytes]:
        """Read bytes at the given virtual address."""
        return self.read_rva(va - self.image_base, size)


def _guid_bytes_to_string(raw: bytes) -> str:
    """Convert 14 raw hex bytes to a GUID-style filename string.

    The 14 bytes are formatted as: XXXXXXXX-XXXX-XXXX-XXXXXXXXXXXX
    (8-4-4-12 lowercase hex chars = 28 hex chars, a proprietary format)
    """
    h = raw.hex()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:28]}"


def _guid_string_to_bytes(guid_str: str) -> bytes:
    """Convert a GUID filename string back to 14 raw bytes."""
    return bytes.fromhex(guid_str.replace("-", ""))


def extract_zeroboot(zb_path: str | Path) -> dict:
    """Extract GUIDs and key material from ZEROBoot.exe.

    Returns dict with:
      intermediate_guid: 14-byte raw GUID for the intermediate EXE file
      host_secdata_guid: 14-byte raw GUID for the host secdata file
      key_material:      14-byte secdata decryption key
    """
    zb_path = Path(zb_path)
    data = zb_path.read_bytes()
    pe = PEFile(data)

    intermediate_guid = pe.read_rva(ZEROBOOT_RVA_INTERMEDIATE_GUID, 14)
    key_material = pe.read_rva(ZEROBOOT_RVA_KEY_MATERIAL, 14)
    host_secdata_guid = pe.read_rva(ZEROBOOT_RVA_HOST_SECDATA_GUID, 14)

    if not all([intermediate_guid, key_material, host_secdata_guid]):
        missing = []
        if not intermediate_guid:
            missing.append("intermediate_guid")
        if not key_material:
            missing.append("key_material")
        if not host_secdata_guid:
            missing.append("host_secdata_guid")
        raise ValueError(
            f"Failed to extract from ZEROBoot.exe: {', '.join(missing)}. "
            f"RVAs may have changed — try pattern-based search."
        )

    return {
        "intermediate_guid": intermediate_guid,
        "intermediate_guid_str": _guid_bytes_to_string(intermediate_guid),
        "host_secdata_guid": host_secdata_guid,
        "host_secdata_guid_str": _guid_bytes_to_string(host_secdata_guid),
        "key_material": key_material,
    }


def extract_intermediate(im_data: bytes) -> dict:
    """Extract GUIDs and key material from a decrypted intermediate EXE.

    Pass the raw decrypted bytes (not a path).

    Returns dict with:
      dongle_config_guid: 14-byte raw GUID for the dongle config file
      game_asset_guid:    14-byte raw GUID for the game asset file
      key_material:       14-byte secdata decryption key
    """
    pe = PEFile(im_data)

    game_asset_guid = pe.read_rva(INTERMEDIATE_RVA_GAME_ASSET_GUID, 14)
    key_material = pe.read_rva(INTERMEDIATE_RVA_KEY_MATERIAL, 14)
    dongle_config_guid = pe.read_rva(INTERMEDIATE_RVA_DONGLE_CONFIG_GUID, 14)

    if not all([game_asset_guid, key_material, dongle_config_guid]):
        missing = []
        if not game_asset_guid:
            missing.append("game_asset_guid")
        if not key_material:
            missing.append("key_material")
        if not dongle_config_guid:
            missing.append("dongle_config_guid")
        raise ValueError(
            f"Failed to extract from intermediate EXE: {', '.join(missing)}. "
            f"RVAs may have changed — try pattern-based search."
        )

    return {
        "dongle_config_guid": dongle_config_guid,
        "dongle_config_guid_str": _guid_bytes_to_string(dongle_config_guid),
        "game_asset_guid": game_asset_guid,
        "game_asset_guid_str": _guid_bytes_to_string(game_asset_guid),
        "key_material": key_material,
    }


def decrypt_secdata(encrypted: bytes, key_material: bytes) -> bytes:
    """Decrypt a 64-byte secdata file with RC4(MD5(key_material))."""
    return rc4.rc4_decrypt(key_material, encrypted)


def load_secdata_host(zero_dir: str | Path, host_secdata_guid: bytes,
                      key_material: bytes) -> bytes:
    """Load and decrypt the host secdata file from the zero directory."""
    guid_str = _guid_bytes_to_string(host_secdata_guid)
    path = Path(zero_dir) / guid_str
    encrypted = path.read_bytes()
    return decrypt_secdata(encrypted, key_material)


def load_secdata_dongle(zero_dir: str | Path, dongle_config_guid: bytes,
                        key_material: bytes) -> bytes:
    """Load and decrypt the dongle config file from the zero directory."""
    guid_str = _guid_bytes_to_string(dongle_config_guid)
    path = Path(zero_dir) / guid_str
    encrypted = path.read_bytes()
    return decrypt_secdata(encrypted, key_material)


def discover_zero_dir(zero_dir: str | Path) -> dict[str, Path]:
    """Scan zero directory and classify files by size/content.

    Returns dict with keys: intermediate_exe, host_secdata, dongle_config,
    game_asset, unknown.

    This is a fallback when binary extraction fails — we can identify
    files heuristically:
      - 64-byte files = secdata/config files
      - ~278KB file with encrypted PE header = intermediate EXE
      - ~35KB file = game asset (for the known configuration)
    """
    zero_dir = Path(zero_dir)
    files: dict[str, list[Path]] = {
        "size_64": [],
        "size_278k": [],
        "size_35k": [],
        "other": [],
    }

    for f in zero_dir.iterdir():
        if not f.is_file():
            continue
        size = f.stat().st_size
        if size == 64:
            files["size_64"].append(f)
        elif 270_000 <= size <= 280_000:
            files["size_278k"].append(f)
        elif 30_000 <= size <= 40_000:
            files["size_35k"].append(f)
        else:
            files["other"].append(f)

    result: dict[str, Path] = {}

    # 64-byte files are secdata/config
    if len(files["size_64"]) >= 1:
        result["host_secdata"] = files["size_64"][0]
    if len(files["size_64"]) >= 2:
        result["dongle_config"] = files["size_64"][1]

    # The intermediate EXE is ~278KB
    if files["size_278k"]:
        result["intermediate_exe"] = files["size_278k"][0]

    # Game asset ~35KB
    if files["size_35k"]:
        result["game_asset"] = files["size_35k"][0]

    result["unknown"] = files["other"]
    return result
