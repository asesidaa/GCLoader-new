"""
game.dat decryption.

game.dat format: [v42 (4 bytes LE)] [Blowfish-encrypted payload]

The Blowfish key is: "Screen Tes" + encode_hex_le(a4) + encode_hex_le(v42)
where a4 comes from the decrypted game asset at offset 0x1060.

Decrypted payload:
  [0:0x294]   Parameter table (165 DWORDs)
  [0x294:]    DLL (PE file, params[39] bytes)
  [...]       Code buffer (shellcode, params[14] bytes)
"""
from __future__ import annotations
import struct

from .blowfish import derive_keys, decrypt_ecb, PI_P_ARRAY, PI_S_BOXES


def encode_hex_le(value: int) -> str:
    """Encode DWORD as 8-char hex via ((nibble) + 48), LSB-nibble-first."""
    return "".join(chr(((value >> (4 * i)) & 0xF) + 48) for i in range(8))


def decrypt_game_dat(data: bytes, a4: int, v42: int) -> dict | None:
    """Decrypt game.dat. Returns dict with params, dll_data, code_data, or None."""
    key_str = "Screen Tes" + encode_hex_le(a4) + encode_hex_le(v42)

    if len(data) <= 4:
        raise ValueError("game.dat too short")

    payload = bytearray(data[4:])

    # Standard Blowfish key schedule
    P, T0, T1, T2, T3 = derive_keys(
        key_str, PI_P_ARRAY,
        PI_S_BOXES[0], PI_S_BOXES[1],
        PI_S_BOXES[2], PI_S_BOXES[3],
    )

    # ECB decrypt payload
    decrypted = decrypt_ecb(payload, P, T0, T1, T2, T3)

    # Verify magic
    header = bytes(decrypted[:0x294])
    if header[:4] != b"TXCE":
        return None

    params = list(struct.unpack_from("<165I", header, 0))
    dll_size = params[39]
    code_size = params[14]
    dll_off = 0x294
    code_off = dll_off + dll_size

    return {
        "params": params,
        "dll_data": bytes(decrypted[dll_off:code_off]),
        "dll_size": dll_size,
        "code_data": bytes(decrypted[code_off:code_off + code_size]),
        "code_size": code_size,
    }
