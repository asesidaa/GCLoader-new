"""
Pure-Python RC4 decryption using MD5(key_material) as the RC4 key.
Replaces the CryptoAPI-based implementation from zeroboot_handoff.py.
"""
from __future__ import annotations
import hashlib


def rc4_decrypt(key_material: bytes, data: bytes) -> bytes:
    """RC4-decrypt data with key = MD5(key_material).

    Equivalent to: CryptAcquireContext → CryptCreateHash(MD5) →
    CryptHashData(key_material) → CryptDeriveKey(RC4) → CryptDecrypt(data).
    """
    key = hashlib.md5(key_material).digest()
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) & 0xFF
        S[i], S[j] = S[j], S[i]

    i = j = 0
    result = bytearray(len(data))
    for k, b in enumerate(data):
        i = (i + 1) & 0xFF
        j = (j + S[i]) & 0xFF
        S[i], S[j] = S[j], S[i]
        result[k] = b ^ S[(S[i] + S[j]) & 0xFF]
    return bytes(result)
