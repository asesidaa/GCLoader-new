"""
JVS serial link layer using pyserial.

Provides SerialLink (pyserial transport) and JvsLink (exchange with
retry). Key difference from zeroboot_handoff: proper read timeouts,
null-byte tolerance, and pyserial instead of Win32 API.
"""
from __future__ import annotations

import time
from typing import Optional

import serial

from .jvs import encode_jvs_frame, JvsFrameParser, DecodedFrame

DEFAULT_BAUD = 115200
DEFAULT_TIMEOUT = 0.02      # 20ms read timeout (matches Win32 transport)
DEFAULT_RETRIES = 5


class SerialLink:
    """pyserial-based transport matching the Win32 transport in ZEROBoot.exe.

    Config: 115200 8N1, DTR=ON, RTS=OFF, no flow control, 20ms read timeout.
    """

    def __init__(self, port: str, baud: int = DEFAULT_BAUD):
        self.port = port
        self._ser: Optional[serial.Serial] = None
        self._baud = baud

    def open(self):
        self._ser = serial.Serial(
            port=self.port,
            baudrate=self._baud,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=DEFAULT_TIMEOUT,
            write_timeout=0,
            rtscts=False,
            dsrdtr=False,
        )
        # Match Win32 DCB: DTR=ENABLE, RTS=DISABLE
        self._ser.dtr = True
        self._ser.rts = False

    def close(self):
        if self._ser and self._ser.is_open:
            self._ser.close()
            self._ser = None

    def write(self, data: bytes) -> None:
        self._ser.write(data)

    def read_chunk(self) -> bytes:
        """Read available bytes, up to 516 (JVS max frame). Non-blocking if
        nothing is waiting; blocks up to timeout for first byte."""
        if self._ser is None or not self._ser.is_open:
            return b""
        n = self._ser.in_waiting
        if n:
            return self._ser.read(min(n, 516))
        # Nothing buffered — try to read one byte with timeout
        b = self._ser.read(1)
        if b:
            # More might have arrived while we were waiting
            n = self._ser.in_waiting
            if n:
                b += self._ser.read(min(n, 516 - 1))
        return b

    def drain(self, duration_s: float = 0.03):
        """Discard any buffered data for duration_s seconds."""
        deadline = time.monotonic() + duration_s
        while time.monotonic() < deadline:
            chunk = self.read_chunk()
            if not chunk:
                break


class JvsLink:
    """JVS link layer with retry.

    send_raw():   send raw wire bytes, read all responses with timeout.
    exchange():   send JVS frame (auto-encoded), wait for response with retry.
    """

    def __init__(self, transport: SerialLink):
        self.transport = transport

    def send_raw(self, wire: bytes, timeout_s: float = 1.0) -> list[DecodedFrame]:
        """Send raw wire bytes; accumulate chunks until complete frame or timeout."""
        parser = JvsFrameParser()
        self.transport.write(wire)
        # Flush write immediately
        self.transport._ser.flush()

        all_raw = bytearray()
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            chunk = self.transport.read_chunk()
            if chunk:
                all_raw.extend(chunk)
                frames = parser.feed(bytes(all_raw))
                if frames:
                    return frames
            elif all_raw:
                # Got data then silence — feed what we have
                frames = parser.feed(bytes(all_raw))
                if frames:
                    return frames
                break
        return []

    def exchange(self, node: int, payload: bytes, label: str = "",
                 timeout_s: float = 1.0) -> bytes:
        """Send JVS frame to node, return response payload with retry."""
        wire = encode_jvs_frame(node, payload)
        parser = JvsFrameParser()
        failures = 0

        while failures <= DEFAULT_RETRIES:
            self.transport.write(wire)
            deadline = time.monotonic() + timeout_s

            while time.monotonic() < deadline:
                chunk = self.transport.read_chunk()
                if not chunk:
                    time.sleep(0.005)
                    continue
                frames = parser.feed(chunk)
                for frame in frames:
                    if not frame.payload:
                        continue
                    s = frame.payload[0]
                    r = frame.payload[1] if len(frame.payload) > 1 else 0xFF
                    if s == 3:  # busy / checksum error → retransmit
                        failures += 1
                        break
                    if s in (1, 2, 4):  # normal / unknown / ack
                        return frame.payload
                else:
                    continue
                break
            else:
                # timeout — retry
                pass
            failures += 1

        raise TimeoutError(f"JvsLink.exchange({label}): no valid response "
                           f"after {DEFAULT_RETRIES} retries")
