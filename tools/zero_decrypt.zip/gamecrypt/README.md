# zero_decrypt — End-to-End Game Decryption

Decrypts `game.exe` from a Taito Type X Zero dongle-protected game, given the
original C: drive image and the JVS security dongle.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        ORIGINAL C: DRIVE                        │
│  ZEROBoot.exe          ← extracts GUIDs + key material (RVAs)   │
│  zero/                 ← encrypted assets named by 28-char GUID │
│    8db9aa26-...  (278K)  intermediate EXE     (RC4-encrypted)  │
│    357460a3-...  (64B)   host secdata          (RC4-encrypted)  │
│    3398e3e8-...  (64B)   dongle config         (RC4-encrypted)  │
│    80095308-...  (35K)   game asset            (RC4-encrypted)  │
├─────────────────────────────────────────────────────────────────┤
│  game.exe            ← the target we decrypt                    │
│  game.dat            ← parameter table + DLL + shellcode        │
└─────────────────────────────────────────────────────────────────┘
```

No GUIDs, keys, or secdata content are hardcoded. Everything is extracted
from the binaries at runtime, so the same tool works across different
harddrive/dongle pairs.

## Quick Start

```bash
# Install dependencies
pip install -r gamecrypt/requirements.txt

# Live mode (dongle connected via USB-serial)
python zero_decrypt.py \
    --base-dir D:/TTXZero \
    --port COM4 \
    --mbr-dump mbr.bin \
    --game-dir D:/game \
    --output-dir D:/out

# Offline mode (replay cached keys)
python zero_decrypt.py \
    --base-dir D:/TTXZero \
    --offline \
    --launcher-key <32-char-hex> \
    --appkey <64-char-hex> \
    --game-dir D:/game \
    --output-dir D:/out
```

**`--mbr-dump`** is required in live mode. The MBR (master boot record)
from the original hard drive contains a 21-byte dongle auth request at
offset `0x190`. Extract it with:

```bash
sudo dd if=/dev/sdX of=mbr.bin bs=512 count=1
```

## How It Works

### Phase Diagram

```
  Dongle ──── Serial (JVS) ──── Host PC
    │                              │
    │  ◄── BIOS bus reset ──────  │  Pre. Preamble
    │  ─── ATA password ────────► │
    │  ◄── MBR auth request ────  │
    │                              │
    │  ◄── Phase 0: ZEROBoot ───  │  Dongle handshake
    │       4-phase exchange       │  → launcher_key (16B)
    │                              │
    │  ─── RC4(launcher_key) ────►│  Phase 1
    │        decrypt intermediate  │  → intermediate EXE (PE)
    │                              │
    │  ◄── Phase 2: Interm. ────  │  Dongle handshake (again)
    │       4-phase exchange       │  → AppKey (32B)
    │                              │
    │  ─── RC4(AppKey[:16]) ────► │  Phase 3
    │        decrypt game asset    │  → game data blob
    │                              │
    └──────────────────────────────┘  (dongle no longer needed)
                    │
                    ▼
    Phase 4-7: Static decryption (CPU only)
      game.dat ──Blowfish──► params + DLL + shellcode
      shellcode ──capstone──► XOR key
      game.exe ──XOR+Blowfish──► decrypted .text
```

### Phases in Detail

**Pre. Preamble (live only)**
1. Bus reset (`E0 00 02 FF 01`) — resets JVS bus
2. Sense node 0x80 (`E0 80 02 FE 80`) — queries dongle, gets ATA password
3. MBR auth request — 21-byte challenge from HDD boot sector at offset `0x190`

**Phase 0. ZEROBoot Handshake** → `launcher_key` (16 bytes)

Four JVS exchanges using the host secdata. Uses LCG-based Variant A and
Variant B encoding (see [Encoding Variants](#encoding-variants)).

| Step | Node | Cmd | Encoding | Input | Output |
|------|------|-----|----------|-------|--------|
| P1 | 0x00 | 0x80 | Variant B | secdata[0:16] | host_challenge |
| P2 | 0x00 | 0x81 | Variant B | secdata[16:48] | dongle_pass |
| P3 | 0x80 | 0x80 | Variant A | dongle_pass | dongle_challenge |
| P4 | 0x80 | 0x85 | Variant A | secdata[48:64] | launcher_key |

**Phase 1. Decrypt Intermediate EXE**

`RC4(MD5(launcher_key))` decrypts the intermediate EXE file (the large
~278KB GUID-named file in `zero/`). Result is a valid PE executable.

**Phase 2. Intermediate Handshake** → `AppKey` (32 bytes)

The intermediate EXE runs its own independent dongle handshake using
the dongle config secdata. Uses Variant A and the new Variant C.

| Step | Node | Cmd | Encoding | Input | Output |
|------|------|-----|----------|-------|--------|
| I | 0x80 | 0x80 | Variant A | DONGLE_PASS | dongle_challenge_1 |
| II | 0x80 | 0x86 | Variant C | DONGLE_CHALLENGE | AppKey[0:16] |
| III | 0x80 | 0x80 | Variant A | DONGLE_PASS | dongle_challenge_2 |
| IV | 0x80 | 0x81 | RAW send, C resp | CANDIDATE_LK+EXTRA | AppKey[16:32] |

**Phase 3. Decrypt Game Asset**

`RC4(MD5(AppKey[:16]))` decrypts the game asset file. The result has an
MD5 header: first 16 bytes are the expected MD5 of the remaining data.

**Phase 4. Extract Keys**

- `a4`: DWORD at offset `0x1060` in the decrypted game asset
- `v42`: First DWORD of `game.dat`

**Phase 5. Decrypt game.dat**

Blowfish-ECB with key `"Screen Tes" + hex_le(a4) + hex_le(v42)`.
Decrypted payload contains:
- Parameter table (165 DWORDs)
- DLL (PE file)
- Code buffer (x86 shellcode for process injection)

**Phase 6. Extract XOR Key**

Capstone disassembles the code buffer's entry code to extract the
56-byte XOR key. The entry code does `XOR [ECX+offset], imm8` for each
byte, with byte 6 using `NOT` instead of XOR.

**Phase 7. Decrypt game.exe**

The XOR key decrypts `params[40:54]` → a 56-byte Blowfish key string.
Standard Blowfish key schedule → ECB-decrypt the `.text` section.

### Dynamic Extraction

All system-specific values are read from binaries at known RVAs:

| Binary | RVA | Content |
|--------|-----|---------|
| ZEROBoot.exe | `0x201A8` | Intermediate EXE GUID (14 raw bytes) |
| ZEROBoot.exe | `0x201C8` | Secdata key material (14 bytes) |
| ZEROBoot.exe | `0x201D8` | Host secdata GUID (14 raw bytes) |
| Intermediate EXE | `0x4539C` | Game asset GUID (14 raw bytes) |
| Intermediate EXE | `0x453CC` | Secdata key material (14 bytes) |
| Intermediate EXE | `0x45438` | Dongle config GUID (14 raw bytes) |

These RVAs are stable across ZEROBoot.exe builds — verified against two
independent builds (Nov 2015 and Mar 2016) with identical PE section
layouts. Only the *data values* at those offsets differ per drive/dongle
pair.

The 14-byte GUIDs use a proprietary 28-character format:
`XXXXXXXX-XXXX-XXXX-XXXXXXXXXXXX` (8-4-4-12 lowercase hex).

### Encoding Variants

All three variants encode a 16-byte key into a 32-byte buffer using an
LCG-based seed word and XOR masking.

| Variant | LCG | Shift | Base | Selector | word[0] | Used by |
|---------|-----|-------|------|----------|---------|---------|
| A | 47261·x+1969 | >>13 | `(low>>1)&0xE+2` | `(high>>3)&0xF` | NOT | ZB P3/P4, IM I/III |
| B | 125637·x+1963 | >>13 | `(low>>3)&0xE+2` | `(high>>2)&0xF` | XOR-combine | ZB P1/P2 |
| C | 8877·x+6543 | >>11 | `(low>>4)&0xE+2` | `(high>>1)&0xF` | XOR-combine + cond-NOT | IM P2, P4 resp |

### Crypto Primitives

| Primitive | Where | Notes |
|-----------|-------|-------|
| RC4 | Secdata, intermediate EXE, game asset | Key = MD5(key_material) |
| MD5 | RC4 key derivation, game asset verification | Standard |
| Blowfish | game.dat, game.exe .text | Modified Feistel: P[0] on LEFT, 17 XOR steps |

The Blowfish implementation uses standard PI-derived P-array and S-boxes
but a custom Feistel network structure verified against the assembly in
the intermediate EXE (`sub_41C180`).

## CLI Reference

```
python zero_decrypt.py [OPTIONS]

--base-dir PATH       Root with ZEROBoot.exe + zero/ subdirectory
--zb-exe PATH         Explicit path to ZEROBoot.exe
--zero-dir PATH       Explicit path to zero/ directory
--game-dir PATH       Directory with game.exe and game.dat
--output-dir PATH     Where to write decrypted output
--port COMX           Serial port (default: COM4)

--offline             Skip dongle, use cached keys
--launcher-key HEX    16-byte launcher key
--appkey HEX          32-byte AppKey
--asset-decrypted PATH Pre-decrypted game asset

--mbr-dump PATH       512-byte MBR boot sector
--mbr-auth HEX        21-byte MBR auth bytes (raw hex)
--skip-preamble       Skip BIOS/MBR preamble (dongle must be ready)

--offset-a4 HEX       Override a4 offset in asset (default: 0x1060)
```

## Package Structure

```
zero_decrypt.py              Thin entry point
gamecrypt/
  __main__.py                CLI argument parsing
  chain.py                   Full orchestrator (phases 0-7)
  extract.py                 PE parsing, GUID/key extraction
  encoding.py                LCG-based Variant A/B/C encode/decode
  rc4.py                     Pure-Python RC4(MD5(key))
  blowfish.py                Modified Blowfish cipher
  game_dat.py                game.dat Blowfish decryption
  game_exe.py                game.exe .text decryption (capstone)
  link.py                    pyserial JVS transport
  jvs.py                     JVS framing (byte-stuffing)
  requirements.txt           pyserial, capstone
```

## Requirements

- Python 3.9+
- pyserial ≥ 3.5
- capstone ≥ 5.0 (for XOR key extraction from shellcode)
- Windows: working COM port for the JVS dongle
- Linux: offline mode works; live mode needs pyserial on a USB-serial adapter

## Security Notes

This tool is for **authorized security research and archival purposes**.
The cryptographic schemes documented here (RC4, MD5, modified Blowfish)
are the game's DRM layer. All keys are device-bound to a specific JVS
dongle + hard drive pair. You must possess the original hardware to
use this tool.
