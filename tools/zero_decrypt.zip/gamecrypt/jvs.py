"""
JVS (JAMMA Video Standard) framing — byte-stuffing encode/decode.

The JVS protocol wraps payloads in frames:
  [SYNC=0xE0] [node] [count] [payload...] [checksum]

Bytes equal to SYNC (0xE0) or MARK (0xD0) are escaped as:
  MARK (0xD0) followed by (byte - 1)
"""
from __future__ import annotations
from dataclasses import dataclass

SYNC = 0xE0
MARK = 0xD0


def encode_jvs_frame(node: int, payload: bytes) -> bytes:
    """Build a byte-stuffed JVS frame from node and payload.
    Checksum is sum of all logical bytes (node + count + payload) & 0xFF.
    """
    count = len(payload) + 1
    logical = bytes([node, count]) + payload
    checksum = sum(logical) & 0xFF
    wire = bytearray([SYNC])
    for b in logical + bytes([checksum]):
        if b in (SYNC, MARK):
            wire.extend((MARK, (b - 1) & 0xFF))
        else:
            wire.append(b)
    return bytes(wire)


@dataclass(frozen=True)
class DecodedFrame:
    node: int
    payload: bytes
    wire: bytes  # raw wire bytes that produced this frame


class JvsFrameParser:
    """JVS frame receive state machine.

    Feeds raw bytes (possibly containing byte-stuffing) and emits complete
    DecodedFrame objects. Tolerates 0x00 null bytes (bus keepalive)."""

    def __init__(self):
        self._collecting = False
        self._escaped = False
        self._decoded = bytearray()
        self._wire = bytearray()
        self.checksum_failures = 0

    def _reset(self):
        self._collecting = False
        self._escaped = False
        self._decoded.clear()
        self._wire.clear()

    def feed(self, chunk: bytes) -> list[DecodedFrame]:
        """Feed raw bytes; return list of completed frames."""
        frames = []
        for b in chunk:
            if b == 0x00 and not self._collecting:
                # null keepalive BETWEEN frames — silently skip
                continue
            if b == SYNC:
                self._collecting = True
                self._escaped = False
                self._decoded.clear()
                self._wire[:] = bytes([SYNC])
                continue
            if not self._collecting:
                continue
            self._wire.append(b)
            if b == MARK:
                self._escaped = True
                continue
            logical = (b + 1) & 0xFF if self._escaped else b
            self._escaped = False
            self._decoded.append(logical)
            if len(self._decoded) < 2:
                continue
            expected = 2 + self._decoded[1]
            if len(self._decoded) < expected:
                continue
            if len(self._decoded) == expected:
                if (sum(self._decoded[:-1]) & 0xFF) == self._decoded[-1]:
                    frames.append(DecodedFrame(
                        node=self._decoded[0],
                        payload=bytes(self._decoded[2:-1]),
                        wire=bytes(self._wire)))
                else:
                    self.checksum_failures += 1
            self._reset()
        return frames
