"""
Variant A/B/C LCG-based encoding — extracted from zeroboot_handoff.py.

All three variants encode a 16-byte key into a 32-byte buffer using:
  - An LCG-based seed word (placed at word[0])
  - A "base" and "selector" derived from the seed to scatter key^chain bytes
  - LCG-based XOR masks on words 1-15

Variant A:  LCG(47261, 1969)   >>13   base=(low>>1)&0xE+2  sel=(high>>3)&0xF  NOT on word[0]
Variant B:  LCG(125637, 1963)  >>13   base=(low>>3)&0xE+2  sel=(high>>2)&0xF  XOR-combine word[0]
Variant C:  LCG(8877, 6543)    >>11   base=(low>>4)&0xE+2  sel=(high>>1)&0xF  XOR-combine + conditional NOT
"""
from __future__ import annotations

import os
import struct
import time
from typing import Callable


def _word(data: bytearray, index: int) -> int:
    offset = index * 2
    return data[offset] | (data[offset + 1] << 8)


def _set_word(data: bytearray, index: int, value: int) -> None:
    offset = index * 2
    value &= 0xFFFF
    data[offset] = value & 0xFF
    data[offset + 1] = (value >> 8) & 0xFF


# ── LCGs ─────────────────────────────────────────────────────────────────────

def _lcg_a(state: int) -> tuple[int, int]:
    state = (47261 * state + 1969) & 0xFFFFFFFF
    return (state >> 13) & 0xFFFF, state


def _lcg_b(state: int) -> tuple[int, int]:
    state = (125637 * state + 1963) & 0xFFFFFFFF
    return (state >> 13) & 0xFFFF, state


def _lcg_c(state: int) -> tuple[int, int]:
    state = (8877 * state + 6543) & 0xFFFFFFFF
    return (state >> 11) & 0xFFFF, state


def _seed_from_time() -> int:
    """Time-based seed matching sub_40DA80: tick ^ (time&0xFFFF) ^ (time>>16)."""
    import ctypes
    seconds = int(time.time())
    tick = ctypes.windll.kernel32.GetTickCount()
    return ((seconds >> 16) ^ seconds ^ tick) & 0xFFFF


def _pick_seed(lcg: Callable, selector_shift: int) -> int:
    """Find a valid seed word where selector != 0."""
    state = _seed_from_time()
    _, state = lcg(state)        # discard one step
    while True:
        candidate, state = lcg(state)
        selector = (candidate >> 8) >> selector_shift & 0xF
        if selector:
            return candidate


# ── Variant A ─────────────────────────────────────────────────────────────────
# LCG: 47261*x+1969, >>13.  base=(low>>1)&0xE+2, sel=(high>>3)&0xF, word[0]=NOT

def encode_variant_a(key: bytes, chain: bytes, *,
                     seed_word: int | None = None,
                     filler: bytes | None = None) -> bytes:
    if filler is None:
        filler = os.urandom(32)
    data = bytearray(filler)
    seed = seed_word if seed_word is not None else _pick_seed(_lcg_a, 3)
    seed &= 0xFFFF
    low, high = seed & 0xFF, seed >> 8
    base = ((low >> 1) & 0xE) + 2
    selector = (high >> 3) & 0xF
    if not selector:
        raise ValueError("variant A: zero selector")
    _set_word(data, 0, seed)
    for i in range(16):
        data[base + (selector ^ i)] = chain[i] ^ key[i]
    state = seed
    _, state = _lcg_a(state)
    for i in range(1, 16):
        mask, state = _lcg_a(state)
        _set_word(data, i, _word(data, i) ^ mask)
    _set_word(data, 0, ~_word(data, 0) & 0xFFFF)  # 16-bit NOT
    return bytes(data)


def decode_variant_a(encoded: bytes, chain: bytes) -> bytes:
    data = bytearray(encoded)
    _set_word(data, 0, ~_word(data, 0) & 0xFFFF)
    seed = _word(data, 0)
    state = seed
    _, state = _lcg_a(state)
    for i in range(1, 16):
        mask, state = _lcg_a(state)
        _set_word(data, i, _word(data, i) ^ mask)
    low, high = data[0], data[1]
    base = ((low >> 1) & 0xE) + 2
    selector = (high >> 3) & 0xF
    return bytes(chain[i] ^ data[base + (selector ^ i)] for i in range(16))


# ── Variant B ─────────────────────────────────────────────────────────────────
# LCG: 125637*x+1963, >>13.  base=(low>>3)&0xE+2, sel=(high>>2)&0xF, XOR-combine

def encode_variant_b(key: bytes, chain: bytes, *,
                     seed_word: int | None = None,
                     filler: bytes | None = None) -> bytes:
    if filler is None:
        filler = os.urandom(32)
    data = bytearray(filler)
    seed = seed_word if seed_word is not None else _pick_seed(_lcg_b, 2)
    seed &= 0xFFFF
    low, high = seed & 0xFF, seed >> 8
    base = ((low >> 3) & 0xE) + 2
    selector = (high >> 2) & 0xF
    if not selector:
        raise ValueError("variant B: zero selector")
    _set_word(data, 0, seed)
    for i in range(16):
        data[base + (selector ^ i)] = chain[i] ^ key[i]
    state = seed
    _, state = _lcg_b(state)
    for i in range(1, 16):
        mask, state = _lcg_b(state)
        _set_word(data, i, _word(data, i) ^ mask)
    combined = _word(data, 0)
    for i in range(1, 16):
        combined ^= _word(data, i)
    _set_word(data, 0, combined)
    return bytes(data)


def decode_variant_b(encoded: bytes, chain: bytes) -> bytes:
    data = bytearray(encoded)
    seed = _word(data, 0)
    for i in range(1, 16):
        seed ^= _word(data, i)
    _set_word(data, 0, seed)
    state = seed
    _, state = _lcg_b(state)
    for i in range(1, 16):
        mask, state = _lcg_b(state)
        _set_word(data, i, _word(data, i) ^ mask)
    low, high = data[0], data[1]
    base = ((low >> 3) & 0xE) + 2
    selector = (high >> 2) & 0xF
    return bytes(chain[i] ^ data[base + (selector ^ i)] for i in range(16))


# ── Variant C ─────────────────────────────────────────────────────────────────
# LCG: 8877*x+6543, >>11.  base=(low>>4)&0xE+2, sel=(high>>1)&0xF, XOR-combine

def encode_variant_c(key: bytes, chain: bytes, *,
                     seed_word: int | None = None,
                     filler_words: list[int] | None = None) -> bytes:
    data = bytearray(32)
    if filler_words is not None:
        for i in range(16):
            _set_word(data, i, filler_words[i] & 0xFFFF)
    else:
        for i in range(16):
            _set_word(data, i, struct.unpack_from('<H', os.urandom(2), 0)[0] & 0x7FFF)

    seed = seed_word if seed_word is not None else _pick_seed(_lcg_c, 1)
    seed &= 0xFFFF
    state = seed
    _, state = _lcg_c(state)
    while True:
        candidate, state = _lcg_c(state)
        c_low, c_high = candidate & 0xFF, candidate >> 8
        base = ((c_low >> 4) & 0xE) + 2
        if (c_high >> 1) & 0xF:
            seed = candidate
            break

    low, high = seed & 0xFF, seed >> 8
    base = ((low >> 4) & 0xE) + 2
    selector = (high >> 1) & 0xF
    for i in range(16):
        data[base + (selector ^ i)] = chain[i] ^ key[i]
    _set_word(data, 0, seed)

    state = seed
    _, state = _lcg_c(state)
    for k in range(1, 16):
        mask, state = _lcg_c(state)
        wk = _word(data, k) ^ mask
        wk_mod = (~wk) & 0xFFFF if (wk >> k) & 1 else wk
        combined = _word(data, 0) ^ wk_mod
        _set_word(data, k, wk)
        _set_word(data, 0, combined)
    return bytes(data)


def decode_variant_c(encoded: bytes, chain: bytes) -> bytes:
    data = bytearray(encoded)
    for k in range(1, 16):
        wk = _word(data, k)
        wk_mod = (~wk) & 0xFFFF if (wk >> k) & 1 else wk
        combined = _word(data, 0) ^ wk_mod
        _set_word(data, 0, combined)
    seed = _word(data, 0)
    state = seed
    _, state = _lcg_c(state)
    for k in range(1, 16):
        mask, state = _lcg_c(state)
        _set_word(data, k, _word(data, k) ^ mask)
    low, high = data[0], data[1]
    base = ((low >> 4) & 0xE) + 2
    selector = (high >> 1) & 0xF
    return bytes(chain[i] ^ data[base + (selector ^ i)] for i in range(16))
