#!/usr/bin/env python3
"""
zero_decrypt.py — End-to-end game decryption from dongle to game.exe.

Usage:
  python zero_decrypt.py --port COM4 --mbr-dump mbr.bin
  python zero_decrypt.py --offline --asset-decrypted asset.decrypted
  python zero_decrypt.py --help
"""
from gamecrypt.__main__ import main

if __name__ == "__main__":
    raise SystemExit(main())
